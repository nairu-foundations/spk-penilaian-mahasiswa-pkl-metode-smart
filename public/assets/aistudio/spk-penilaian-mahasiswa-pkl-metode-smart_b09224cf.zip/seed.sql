-- =====================================================================
-- SEED.SQL: Data Awal Realistis untuk Supabase (PostgreSQL)
-- =====================================================================

-- 1. SITE SETTINGS
INSERT INTO public.site_settings (key, value, tipe) VALUES
('nama_situs', 'SMART PKL', 'text'),
('tagline', 'Sistem Pendukung Keputusan Pemilihan Tempat PKL', 'text'),
('nama_perusahaan_host', 'PT Seven Inc.', 'text'),
('deskripsi_singkat', 'Platform perangkingan tempat PKL mahasiswa dengan metode SMART yang objektif dan transparan.', 'text'),
('email_kontak', 'pkl-support@seveninc.co.id', 'text'),
('telepon_kontak', '+62 821-3456-7890', 'text'),
('alamat_kontak', 'Jl. Ringroad Utara No. 7, Sleman, D.I. Yogyakarta', 'text'),
('teks_footer', '© 2026 PT Seven Inc. Hak cipta dilindungi undang-undang. Bersama membangun generasi profesional yang disiplin dan kompeten.', 'text'),
('quote_login', 'Disiplin hari ini, kesuksesan esok hari.', 'text')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- 2. HERO SECTION
INSERT INTO public.hero_section (id, judul, subjudul, teks_tombol_utama, link_tombol_utama, teks_tombol_sekunder, link_tombol_sekunder)
VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'Temukan Tempat PKL Terbaik Sesuai Preferensi & Kompetensi Anda',
  'Didukung metode ilmiah SMART (Simple Multi Attribute Rating Technique) yang objektif, transparan, dan mempertimbangkan kesesuaian prodi, fasilitas, reputasi, hingga prospek karier.',
  'Mulai Hitung Rekomendasi',
  '/proses-smart',
  'Jelajahi Mitra PKL',
  '/tempat-pkl'
) ON CONFLICT (id) DO NOTHING;

-- 3. KRITERIA
INSERT INTO public.kriteria (id, kode, nama, tipe, bobot_awal, deskripsi, urutan, aktif) VALUES
('b0000000-0000-0000-0000-000000000001', 'C1', 'Kesesuaian Bidang dengan Prodi', 'benefit', 30.00, 'Tingkat relevansi proyek kerja industri dengan kurikulum akademik program studi mahasiswa.', 1, true),
('b0000000-0000-0000-0000-000000000002', 'C2', 'Jarak / Lokasi dari Kampus', 'cost', 15.00, 'Estimasi jarak fisik atau kemudahan akses transportasi menuju kantor mitra.', 2, true),
('b0000000-0000-0000-0000-000000000003', 'C3', 'Uang Saku & Fasilitas Kerja', 'benefit', 15.00, 'Insentif finansial bulanan, makan siang, laptop, dan akomodasi pendukung.', 3, true),
('b0000000-0000-0000-0000-000000000004', 'C4', 'Reputasi & Kredibilitas Mitra', 'benefit', 20.00, 'Tingkat kemapanan industri, sertifikasi standar kerja, dan portofolio produk.', 4, true),
('b0000000-0000-0000-0000-000000000005', 'C5', 'Peluang Direkrut / Jalur Karier', 'benefit', 20.00, 'Histori penyerapan alumni PKL menjadi karyawan tetap (full-time hire).', 5, true)
ON CONFLICT (id) DO NOTHING;

-- 4. PERIODE PKL
INSERT INTO public.periode_pkl (id, nama_periode, tanggal_mulai, tanggal_selesai, status) VALUES
('c0000000-0000-0000-0000-000000000001', 'Periode 1 - 2025', '2025-01-01', '2025-06-30', 'Aktif'),
('c0000000-0000-0000-0000-000000000002', 'Periode 2 - 2025', '2025-07-01', '2025-12-31', 'Nonaktif'),
('c0000000-0000-0000-0000-000000000003', 'Periode 1 - 2024', '2024-01-01', '2024-06-30', 'Nonaktif')
ON CONFLICT (id) DO NOTHING;

-- 5. ALTERNATIF TEMPAT PKL
INSERT INTO public.alternatif (id, kode, nama_perusahaan, bidang, alamat, kota, kuota, kuota_terisi, deskripsi, kontak, website, aktif) VALUES
('d0000000-0000-0000-0000-000000000001', 'A1', 'PT Telkom Indonesia (Witel Digital)', 'Telekomunikasi & Digital Services', 'Jl. Yos Sudarso No. 9', 'Yogyakarta', 6, 2, 'Badan Usaha Milik Negara penyedia ekosistem digital nasional.', 'hr-magang@telkom.co.id', 'https://telkom.co.id', true),
('d0000000-0000-0000-0000-000000000002', 'A2', 'PT Seven Inc. (Seven Media Digital)', 'Software House & Creative Agency', 'Jl. Ringroad Utara No. 7, Sleman', 'Sleman', 8, 5, 'Perusahaan teknologi yang berfokus pada SaaS enterprise dan web engineering.', 'careers@seveninc.co.id', 'https://seveninc.co.id', true),
('d0000000-0000-0000-0000-000000000003', 'A3', 'Gojek Tech Hub (GoTo Ecosystem)', 'Technology & E-Commerce', 'Jl. Kaliurang KM 6.5', 'Sleman', 4, 3, 'Pusat riset dan pengembangan software berskala jutaan pengguna harian.', 'internship@goto.com', 'https://gotocompany.com', true),
('d0000000-0000-0000-0000-000000000004', 'A4', 'Dinas Komunikasi dan Informatika (Diskominfo)', 'Pemerintahan & Pelayanan Publik', 'Kompleks Kepatihan Danurejan', 'Yogyakarta', 5, 1, 'Instansi pemerintah provinsi pengelola SPBE dan data center daerah.', 'kepegawaian@diskominfo.jogjaprov.go.id', 'https://diskominfo.jogjaprov.go.id', true),
('d0000000-0000-0000-0000-000000000005', 'A5', 'Bank Central Asia (BCA Kantor Wilayah)', 'Perbankan & Financial Technology', 'Jl. Jenderal Sudirman No. 49', 'Yogyakarta', 5, 2, 'Lembaga keuangan swasta dengan ekosistem IT berstandar internasional.', 'recruitment_bca@bca.co.id', 'https://bca.co.id', true),
('d0000000-0000-0000-0000-000000000006', 'A6', 'Gameloft Indonesia Studio', 'Game Development & Interactive Media', 'Jl. Magelang No. 12', 'Sleman', 4, 2, 'Studio game internasional pengembang judul-judul mobile ternama.', 'recruitment-jogja@gameloft.com', 'https://gameloft.com', true),
('d0000000-0000-0000-0000-000000000007', 'A7', 'PT Media Sarana Data (GMEDIA)', 'Internet Service Provider & Cloud', 'Jl. Cik Di Tiro No. 34', 'Yogyakarta', 6, 3, 'Penyedia infrastruktur jaringan internet dedicated dan managed cloud.', 'hrd@gmedia.co.id', 'https://gmedia.net.id', true),
('d0000000-0000-0000-0000-000000000008', 'A8', 'Qwords Cloud Web Hosting', 'Cloud Infrastructure & Web Hosting', 'Jl. Palagan Tentara Pelajar No. 81', 'Sleman', 4, 1, 'Perusahaan domain internasional, VPS, dan solusi enterprise web.', 'career@qwords.co.id', 'https://qwords.com', true),
('d0000000-0000-0000-0000-000000000009', 'A9', 'Kuncie Edukasi Inovasi', 'EdTech & Digital Learning', 'Jl. Gejayan No. 12', 'Sleman', 5, 2, 'Platform upskilling profesional dan edukasi interaktif.', 'people@kuncie.com', 'https://kuncie.com', true),
('d0000000-0000-0000-0000-000000000010', 'A10', 'Suitmedia Digital Agency', 'Full-Service Digital Consultancy', 'Jl. Wahid Hasyim No. 55', 'Yogyakarta', 4, 1, 'Konsultan transformasi digital spesialis UI/UX dan web mobile.', 'careers@suitmedia.com', 'https://suitmedia.com', true)
ON CONFLICT (id) DO NOTHING;

-- 6. NILAI ALTERNATIF
INSERT INTO public.nilai_alternatif (alternatif_id, kriteria_id, nilai) VALUES
('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 5),
('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000002', 3),
('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000003', 4),
('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000004', 5),
('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000005', 4),

('d0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', 5),
('d0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', 2),
('d0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000003', 4),
('d0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000004', 4),
('d0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000005', 5),

('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000001', 5),
('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000002', 2),
('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 5),
('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000004', 5),
('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000005', 5)
ON CONFLICT (alternatif_id, kriteria_id) DO NOTHING;

-- 7. FITUR CMS
INSERT INTO public.fitur (ikon, judul, deskripsi, urutan, aktif) VALUES
('Calculator', 'Algoritma SMART Transparan', 'Menghitung nilai utilitas benefit dan cost secara matematis serta membuka rincian rumus tanpa kotak hitam.', 1, true),
('SlidersHorizontal', 'Kustomisasi Bobot Preferensi', 'Mahasiswa dapat menyesuaikan skala prioritas pribadi secara interaktif sesuai kondisi masing-masing.', 2, true),
('Building2', 'Database Mitra Terverifikasi', 'Informasi lengkap profil instansi, kuota penerimaan, alamat, dan kontak person industri.', 3, true),
('FileCheck', 'Pengajuan PKL Terintegrasi', 'Ajukan lamaran magang langsung dari hasil rekomendasi terbaik dan pantau verifikasi koordinator.', 4, true),
('BarChart3', 'Visualisasi & Export Hasil', 'Grafik perbandingan skor alternatif serta fitur ekspor laporan ke format cetak dan spreadsheet.', 5, true),
('ShieldCheck', 'Keamanan Berbasis Role (RBAC)', 'Pemisahan hak akses yang tegas antara mahasiswa dan admin institusi.', 6, true);

-- 8. LANGKAH PENGGUNAAN
INSERT INTO public.langkah_penggunaan (nomor, judul, deskripsi) VALUES
(1, 'Buat Akun & Lengkapi Profil', 'Daftarkan diri dengan NIM, program studi, dan nomor WhatsApp aktif.'),
(2, 'Atur Bobot Prioritas Anda', 'Sesuaikan derajat kepentingan relevansi prodi, jarak kantor, atau fasilitas.'),
(3, 'Hitung & Analisis Hasil SMART', 'Lihat skor utilitas dan peringkat mitra secara objektif dan instan.'),
(4, 'Kirim Pengajuan ke Mitra', 'Pilih tempat PKL peringkat teratas dan ajukan persetujuan resmi.');

-- 9. FAQ
INSERT INTO public.faq (pertanyaan, jawaban, urutan, aktif) VALUES
('Apa itu metode SMART dalam pemilihan tempat PKL?', 'SMART (Simple Multi Attribute Rating Technique) adalah metode ilmiah yang mengevaluasi alternatif berdasarkan pembobotan nilai utilitas benefit dan cost.', 1, true),
('Apakah saya bisa mengubah bobot kriteria?', 'Ya, Anda dapat menyesuaikan slider prioritas sesuai pertimbangan pribadi Anda.', 2, true),
('Bagaimana kriteria benefit dan cost dihitung?', 'Benefit dinilai semakin besar nilainya semakin tinggi utilitasnya, sedangkan cost dinilai semakin kecil nilainya semakin tinggi utilitasnya.', 3, true);
