-- =====================================================================
-- SCHEMA.SQL: Skema Database SPK Pemilihan Tempat PKL (Metode SMART)
-- Platform: Supabase (PostgreSQL)
-- =====================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
DO $$ BEGIN
  CREATE TYPE role_type AS ENUM ('mahasiswa', 'admin');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE kriteria_type AS ENUM ('benefit', 'cost');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE status_pengajuan_type AS ENUM ('diajukan', 'disetujui', 'ditolak');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 3. PROFILES (Relasi ke auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nama TEXT NOT NULL,
  nim TEXT,
  email TEXT,
  prodi TEXT,
  angkatan TEXT,
  no_hp TEXT,
  role role_type NOT NULL DEFAULT 'mahasiswa',
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. KRITERIA
CREATE TABLE IF NOT EXISTS public.kriteria (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  kode VARCHAR(10) NOT NULL UNIQUE,
  nama TEXT NOT NULL,
  tipe kriteria_type NOT NULL DEFAULT 'benefit',
  bobot_awal NUMERIC(6,2) NOT NULL DEFAULT 20.00,
  deskripsi TEXT,
  urutan INT NOT NULL DEFAULT 1,
  aktif BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. ALTERNATIF (Tempat PKL)
CREATE TABLE IF NOT EXISTS public.alternatif (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  kode VARCHAR(10) NOT NULL UNIQUE,
  nama_perusahaan TEXT NOT NULL,
  bidang TEXT NOT NULL,
  alamat TEXT,
  kota VARCHAR(100),
  kuota INT NOT NULL DEFAULT 5,
  kuota_terisi INT NOT NULL DEFAULT 0,
  deskripsi TEXT,
  logo_url TEXT,
  kontak TEXT,
  email TEXT,
  website TEXT,
  aktif BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. SKALA NILAI (Rubrik Penilaian 1 - 5)
CREATE TABLE IF NOT EXISTS public.skala_nilai (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  kriteria_id UUID NOT NULL REFERENCES public.kriteria(id) ON DELETE CASCADE,
  nilai INT NOT NULL CHECK (nilai >= 1 AND nilai <= 5),
  keterangan TEXT NOT NULL,
  UNIQUE(kriteria_id, nilai)
);

-- 7. NILAI ALTERNATIF (Matrix Penilaian Alternatif terhadap Kriteria)
CREATE TABLE IF NOT EXISTS public.nilai_alternatif (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  alternatif_id UUID NOT NULL REFERENCES public.alternatif(id) ON DELETE CASCADE,
  kriteria_id UUID NOT NULL REFERENCES public.kriteria(id) ON DELETE CASCADE,
  nilai NUMERIC(6,2) NOT NULL DEFAULT 1.0,
  UNIQUE(alternatif_id, kriteria_id)
);

-- 8. PERIODE PKL
CREATE TABLE IF NOT EXISTS public.periode_pkl (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nama_periode TEXT NOT NULL,
  tanggal_mulai DATE NOT NULL,
  tanggal_selesai DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Aktif'
);

-- 9. HASIL PERHITUNGAN SMART
CREATE TABLE IF NOT EXISTS public.hasil_perhitungan (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  bobot_snapshot JSONB NOT NULL,
  catatan TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. DETAIL HASIL PERHITUNGAN & RANKING
CREATE TABLE IF NOT EXISTS public.hasil_detail (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  hasil_id UUID NOT NULL REFERENCES public.hasil_perhitungan(id) ON DELETE CASCADE,
  alternatif_id UUID NOT NULL REFERENCES public.alternatif(id) ON DELETE CASCADE,
  skor_akhir NUMERIC(8,4) NOT NULL,
  peringkat INT NOT NULL,
  utilitas JSONB NOT NULL,
  kategori VARCHAR(50)
);

-- 11. PENGAJUAN PKL
CREATE TABLE IF NOT EXISTS public.pengajuan_pkl (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  alternatif_id UUID NOT NULL REFERENCES public.alternatif(id) ON DELETE CASCADE,
  periode_id UUID REFERENCES public.periode_pkl(id) ON DELETE SET NULL,
  status status_pengajuan_type NOT NULL DEFAULT 'diajukan',
  catatan_admin TEXT,
  skor_smart NUMERIC(8,4),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. TABEL KONTEN DINAMIS (CMS PENGGANTI HARDCODE)
CREATE TABLE IF NOT EXISTS public.site_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  tipe VARCHAR(20) NOT NULL DEFAULT 'text',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.hero_section (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  judul TEXT NOT NULL,
  subjudul TEXT NOT NULL,
  teks_tombol_utama TEXT NOT NULL,
  link_tombol_utama TEXT NOT NULL,
  teks_tombol_sekunder TEXT,
  link_tombol_sekunder TEXT,
  gambar_url TEXT
);

CREATE TABLE IF NOT EXISTS public.fitur (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ikon VARCHAR(50) NOT NULL,
  judul TEXT NOT NULL,
  deskripsi TEXT NOT NULL,
  urutan INT NOT NULL DEFAULT 1,
  aktif BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS public.langkah_penggunaan (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nomor INT NOT NULL,
  judul TEXT NOT NULL,
  deskripsi TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.faq (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  pertanyaan TEXT NOT NULL,
  jawaban TEXT NOT NULL,
  urutan INT NOT NULL DEFAULT 1,
  aktif BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS public.testimoni (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nama TEXT NOT NULL,
  jabatan TEXT NOT NULL,
  instansi TEXT,
  isi TEXT NOT NULL,
  foto_url TEXT,
  aktif BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS public.pengumuman (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  judul TEXT NOT NULL,
  isi TEXT NOT NULL,
  kategori VARCHAR(50) NOT NULL DEFAULT 'Pengumuman',
  tanggal TEXT NOT NULL,
  dipublikasi BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.menu_navigasi (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  label TEXT NOT NULL,
  path TEXT NOT NULL,
  role_akses VARCHAR(20) NOT NULL DEFAULT 'semua',
  urutan INT NOT NULL DEFAULT 1,
  aktif BOOLEAN NOT NULL DEFAULT true
);

-- =====================================================================
-- HELPER FUNCTIONS & TRIGGERS
-- =====================================================================

-- Fungsi cek role admin secara aman
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger otomatis saat user baru register di Supabase Auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, nama, nim, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nama', NEW.email),
    NEW.raw_user_meta_data->>'nim',
    NEW.email,
    COALESCE((NEW.raw_user_meta_data->>'role')::role_type, 'mahasiswa'::role_type)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =====================================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kriteria ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alternatif ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skala_nilai ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nilai_alternatif ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.periode_pkl ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hasil_perhitungan ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hasil_detail ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pengajuan_pkl ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hero_section ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fitur ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.langkah_penggunaan ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faq ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.testimoni ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pengumuman ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_navigasi ENABLE ROW LEVEL SECURITY;

-- 1. Konten Publik (SELECT: Semua, INSERT/UPDATE/DELETE: Hanya Admin)
CREATE POLICY "Publik dapat membaca kriteria" ON public.kriteria FOR SELECT USING (true);
CREATE POLICY "Admin mengelola kriteria" ON public.kriteria FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca alternatif" ON public.alternatif FOR SELECT USING (true);
CREATE POLICY "Admin mengelola alternatif" ON public.alternatif FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca skala" ON public.skala_nilai FOR SELECT USING (true);
CREATE POLICY "Admin mengelola skala" ON public.skala_nilai FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca nilai matriks" ON public.nilai_alternatif FOR SELECT USING (true);
CREATE POLICY "Admin mengelola nilai matriks" ON public.nilai_alternatif FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca periode" ON public.periode_pkl FOR SELECT USING (true);
CREATE POLICY "Admin mengelola periode" ON public.periode_pkl FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca CMS" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "Admin mengelola CMS settings" ON public.site_settings FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca hero" ON public.hero_section FOR SELECT USING (true);
CREATE POLICY "Admin mengelola hero" ON public.hero_section FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca fitur" ON public.fitur FOR SELECT USING (true);
CREATE POLICY "Admin mengelola fitur" ON public.fitur FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca langkah" ON public.langkah_penggunaan FOR SELECT USING (true);
CREATE POLICY "Admin mengelola langkah" ON public.langkah_penggunaan FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca faq" ON public.faq FOR SELECT USING (true);
CREATE POLICY "Admin mengelola faq" ON public.faq FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca testimoni" ON public.testimoni FOR SELECT USING (true);
CREATE POLICY "Admin mengelola testimoni" ON public.testimoni FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca pengumuman" ON public.pengumuman FOR SELECT USING (true);
CREATE POLICY "Admin mengelola pengumuman" ON public.pengumuman FOR ALL USING (public.is_admin());

CREATE POLICY "Publik dapat membaca menu" ON public.menu_navigasi FOR SELECT USING (true);
CREATE POLICY "Admin mengelola menu" ON public.menu_navigasi FOR ALL USING (public.is_admin());

-- 2. Profiles
CREATE POLICY "User dapat membaca profil sendiri atau admin membaca semua" ON public.profiles
  FOR SELECT USING (auth.uid() = id OR public.is_admin());
CREATE POLICY "User dapat memperbarui profil sendiri" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- 3. Hasil Perhitungan & Detail
CREATE POLICY "Mahasiswa membaca hasil miliknya, Admin membaca semua" ON public.hasil_perhitungan
  FOR SELECT USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "Mahasiswa membuat hasil miliknya" ON public.hasil_perhitungan
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Mahasiswa membaca detail hasil miliknya" ON public.hasil_detail
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.hasil_perhitungan
      WHERE public.hasil_perhitungan.id = public.hasil_detail.hasil_id
      AND (public.hasil_perhitungan.user_id = auth.uid() OR public.is_admin())
    )
  );

-- 4. Pengajuan PKL
CREATE POLICY "Mahasiswa membaca pengajuan miliknya, Admin membaca semua" ON public.pengajuan_pkl
  FOR SELECT USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "Mahasiswa membuat pengajuan" ON public.pengajuan_pkl
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admin mengubah status pengajuan" ON public.pengajuan_pkl
  FOR UPDATE USING (public.is_admin());
